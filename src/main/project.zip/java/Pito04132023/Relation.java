/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSyste32023;
m/Templates/Classes/Interface.java to edit this template
 */
package Pito04132023;
/**
 *
 * @author Pitok
 */
public interface Relation {
    public boolean isGreater( Object a, Object b); 
    public boolean isLess( Object a, Object b); 
    public boolean isEqual( Object a, Object b);
}
