/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pito18032023;

/**
 *
 * @author Pitok
 */
import java.awt.*;
public class SampleFrame extends Frame{
    public static void main(String args []){
        SampleFrame sf = new SampleFrame();
        sf.setSize(500, 250); //Coba hilangkan baris ini
        sf.setVisible(true); //Coba hilangkan baris ini
        
    }
}
