/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pito16032023;

/**
 *
 * @author Pitok
 */
public class Latihan632 {
    //latihan module 6 (6.5.3Cetak Seratus Kali) do while loop
    public static void main(String[] args){
        int i = 1;
        do{
            System.out.println("Baghaztra Van Ril");
            i++;
        }while(i<=100);
    }
}
