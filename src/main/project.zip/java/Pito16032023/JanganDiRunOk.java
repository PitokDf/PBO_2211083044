package Pito16032023;
import javax.swing.JOptionPane;
public class JanganDiRunOk {
    //latihan module 6 (6.5.3Cetak Seratus Kali) for loop
    public static void main(String[] args){
        for(int i =1;i<=1000000;i++){
            JOptionPane.showMessageDialog(null, "Hallo Dunia");
        }
    }
}