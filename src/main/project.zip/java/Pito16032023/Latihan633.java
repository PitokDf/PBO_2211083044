/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pito16032023;

/**
 *
 * @author Pitok
 */
import javax.swing.JOptionPane;
public class Latihan633 {
    //latihan module 6 (6.5.3Cetak Seratus Kali) for loop
    public static void main(String[] args){
        for(int i =1;i<=100;i++){
           System.out.println(i+". Hallo Dunia");
        }
    }
}
