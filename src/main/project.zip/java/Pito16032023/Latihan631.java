/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pito16032023;

/**
 *
 * @author Pitok
 */
public class Latihan631 {
    //latihan module 6 (6.5.3Cetak Seratus Kali) while loop
    public static void main(String[] args){
        int i = 1;
        while(i<=100){
            System.out.println("Baghaztra Van Ril");
            i++;
        }
    }
}
