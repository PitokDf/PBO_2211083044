/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pito07032023;

/**
 *
 * @author Pitok
 */
public class Latihan1 {
    public static void main(String[] args){
        int number = 10;
        char letter = 'a';
        boolean result = true;
        String str = "Hello";
        
        System.out.println("Number = "+number);
        System.out.println("Letter = "+letter);
        System.out.println("Result = "+result);
        System.out.println("str = "+str);
        
    }
}
