package Pito4082023;

public class Mars extends Planet{
    @Override
    public void WEdar() {
        // TODO Auto-generated method stub
        super.WEdar();
        System.out.println("687 Hari");
    }
    public static void main(String[] args){
        Mars mr = new Mars();
        mr.WEdar();
    }
}
