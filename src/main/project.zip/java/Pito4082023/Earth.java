package Pito4082023;

public class Earth extends Planet{
    @Override
    public void WEdar() {
        // TODO Auto-generated method stub
        super.WEdar();
        System.out.println("365 Hari.");
        
    }
    public static void main(String[] args){
        Earth b = new Earth();
        b.WEdar();

    }
}
