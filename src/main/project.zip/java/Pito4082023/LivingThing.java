package Pito4082023;

public abstract class LivingThing {
    public void bernafas(){
        System.out.println("Bernafas...");
    }
    public void makan(){
        System.out.println("makan...");
    }
    public abstract void berjalan();
}
