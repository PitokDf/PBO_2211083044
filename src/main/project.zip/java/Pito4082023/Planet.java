package Pito4082023;

public abstract class Planet {
    public void WEdar(){
        System.out.println("Waktu Edar...");
    }
}
