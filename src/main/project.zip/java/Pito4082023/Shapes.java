package Pito4082023;

public abstract class Shapes {
    public abstract double getArea();
    public abstract String getname();
}
